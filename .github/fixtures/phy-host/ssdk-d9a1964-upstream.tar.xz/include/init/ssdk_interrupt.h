/*
 * Copyright (c) 2017, The Linux Foundation. All rights reserved.
 * Copyright (c) 2023-2024, Qualcomm Innovation Center, Inc. All rights reserved.
 *
 * Permission to use, copy, modify, and/or distribute this software for
 * any purpose with or without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all copies.
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
 * OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "ssdk_plat.h"

#ifndef _SSDK_INTERRUPT_H_
#define _SSDK_INTERRUPT_H_

#ifdef __cplusplus
extern "C" {
#endif                          /* __cplusplus */
int qca_switch_enable_intr(struct qca_phy_priv *priv, a_uint32_t intr_mask);
int qca_switch_disable_intr(struct qca_phy_priv *priv, a_uint32_t intr_mask);
int qca_phy_enable_intr(struct qca_phy_priv *priv);
int qca_phy_disable_intr(struct qca_phy_priv *priv);
int qca_intr_init(struct qca_phy_priv *priv);
void qca_intr_deinit(struct qca_phy_priv *priv);
void qca_intr_work_pause(struct qca_phy_priv *priv);
void qca_intr_work_resume(struct qca_phy_priv *priv);
void qca_link_change_task(struct qca_phy_priv *priv);
#ifdef __cplusplus
}
#endif                          /* __cplusplus */
#endif                          /* _SSDK_INTERRUPT_H */
