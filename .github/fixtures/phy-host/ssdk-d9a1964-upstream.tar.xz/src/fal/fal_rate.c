/*
 * Copyright (c) 2012, The Linux Foundation. All rights reserved.
 * Copyright (c) 2024 Qualcomm Innovation Center, Inc. All rights reserved.
 *
 * Permission to use, copy, modify, and/or distribute this software for
 * any purpose with or without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all copies.
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
 * OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */


/**
 * @defgroup fal_rate FAL_RATE
 * @{
 */
#include "sw.h"
#include "fal_rate.h"
#include "hsl_api.h"
#include "adpt.h"

sw_error_t fal_rate_queue_egrl_set(a_uint32_t dev_id, fal_port_t port_id, fal_queue_t queue_id, a_uint32_t * speed, a_bool_t enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_queue_egrl_set, dev_id, port_id, queue_id, speed, enable)

sw_error_t fal_rate_queue_egrl_get(a_uint32_t dev_id, fal_port_t port_id, fal_queue_t queue_id, a_uint32_t * speed, a_bool_t * enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_queue_egrl_get, dev_id, port_id, queue_id, speed, enable)

sw_error_t fal_rate_port_egrl_set(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * speed, a_bool_t enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_egrl_set, dev_id, port_id, speed, enable)

sw_error_t fal_rate_port_egrl_get(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * speed, a_bool_t * enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_egrl_get, dev_id, port_id, speed, enable)

sw_error_t fal_rate_port_inrl_set(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * speed, a_bool_t enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_inrl_set, dev_id, port_id, speed, enable)

sw_error_t fal_rate_port_inrl_get(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * speed, a_bool_t * enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_inrl_get, dev_id, port_id, speed, enable)

sw_error_t fal_storm_ctrl_frame_set(a_uint32_t dev_id, fal_port_t port_id, fal_storm_type_t frame_type, a_bool_t enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(storm_ctrl_frame_set, dev_id, port_id, frame_type, enable)

sw_error_t fal_storm_ctrl_frame_get(a_uint32_t dev_id, fal_port_t port_id, fal_storm_type_t frame_type, a_bool_t * enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(storm_ctrl_frame_get, dev_id, port_id, frame_type, enable)

sw_error_t fal_storm_ctrl_rate_set(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * rate)
    DEFINE_FAL_FUNC_HSL_EXPORT(storm_ctrl_rate_set, dev_id, port_id, rate)

sw_error_t fal_storm_ctrl_rate_get(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t * rate)
    DEFINE_FAL_FUNC_HSL_EXPORT(storm_ctrl_rate_get, dev_id, port_id, rate)

sw_error_t fal_rate_port_policer_set(a_uint32_t dev_id, fal_port_t port_id, fal_port_policer_t * policer)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_policer_set, dev_id, port_id, policer)

sw_error_t fal_rate_port_policer_get(a_uint32_t dev_id, fal_port_t port_id, fal_port_policer_t * policer)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_policer_get, dev_id, port_id, policer)

sw_error_t fal_rate_port_shaper_set(a_uint32_t dev_id, fal_port_t port_id, a_bool_t enable, fal_egress_shaper_t * shaper)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_shaper_set, dev_id, port_id, enable, shaper)

sw_error_t fal_rate_port_shaper_get(a_uint32_t dev_id, fal_port_t port_id, a_bool_t * enable, fal_egress_shaper_t * shaper)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_shaper_get, dev_id, port_id, enable, shaper)

sw_error_t fal_rate_queue_shaper_set(a_uint32_t dev_id, fal_port_t port_id, fal_queue_t queue_id, a_bool_t enable, fal_egress_shaper_t * shaper)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_queue_shaper_set, dev_id, port_id, queue_id, enable, shaper)

sw_error_t fal_rate_queue_shaper_get(a_uint32_t dev_id, fal_port_t port_id, fal_queue_t queue_id, a_bool_t * enable, fal_egress_shaper_t * shaper)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_queue_shaper_get, dev_id, port_id, queue_id, enable, shaper)

sw_error_t fal_rate_acl_policer_set(a_uint32_t dev_id, a_uint32_t policer_id, fal_acl_policer_t * policer)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_acl_policer_set, dev_id, policer_id, policer)

sw_error_t fal_rate_acl_policer_get(a_uint32_t dev_id, a_uint32_t policer_id, fal_acl_policer_t * policer)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_acl_policer_get, dev_id, policer_id, policer)

sw_error_t fal_rate_port_add_rate_byte_set(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t number)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_add_rate_byte_set, dev_id, port_id, number)

sw_error_t fal_rate_port_add_rate_byte_get(a_uint32_t dev_id, fal_port_t port_id, a_uint32_t *number)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_add_rate_byte_get, dev_id, port_id, number)

sw_error_t fal_rate_port_gol_flow_en_set(a_uint32_t dev_id, fal_port_t port_id, a_bool_t enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_gol_flow_en_set, dev_id, port_id, enable)

sw_error_t fal_rate_port_gol_flow_en_get(a_uint32_t dev_id, fal_port_t port_id, a_bool_t* enable)
    DEFINE_FAL_FUNC_HSL_EXPORT(rate_port_gol_flow_en_get, dev_id, port_id, enable)

